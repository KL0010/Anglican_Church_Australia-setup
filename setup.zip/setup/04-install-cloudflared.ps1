# =========================================
# 04-install-cloudflared.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Checking Cloudflare Tunnel ==="

function Test-Cloudflared {
    $cloudflared = Get-Command "cloudflared" -ErrorAction SilentlyContinue

    if ($cloudflared) {
        Write-Host "[OK] cloudflared found"
        cloudflared --version
        return $true
    }

    return $false
}

$cloudflaredOk = Test-Cloudflared

if ($cloudflaredOk) {
    Write-Host ""
    Write-Host "=== Cloudflare Tunnel check complete ==="
    exit 0
}

Write-Host "[MISSING] cloudflared not found"
Write-Host "Installing Cloudflare Tunnel..."

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] winget not found"
    exit 1
}

winget install Cloudflare.cloudflared `
    --accept-source-agreements `
    --accept-package-agreements

Write-Host ""
Write-Host "Refreshing PATH..."

$machinePath = [System.Environment]::GetEnvironmentVariable(
    "Path",
    [System.EnvironmentVariableTarget]::Machine
)

$userPath = [System.Environment]::GetEnvironmentVariable(
    "Path",
    [System.EnvironmentVariableTarget]::User
)

$env:Path = "$machinePath;$userPath"

Start-Sleep -Seconds 5

Write-Host ""
Write-Host "Verifying cloudflared installation..."

$cloudflaredOk = Test-Cloudflared

if ($cloudflaredOk) {
    Write-Host ""
    Write-Host "[OK] cloudflared installed successfully"
    Write-Host "=== Cloudflare Tunnel check complete ==="
    exit 0
}

Write-Host ""
Write-Host "[WARN] cloudflared installer completed, but this PowerShell session cannot see it yet."
Write-Host "Close PowerShell, reopen as Administrator, then run:"
Write-Host "cloudflared --version"
Write-Host ".\04-install-cloudflared.ps1"

exit 0