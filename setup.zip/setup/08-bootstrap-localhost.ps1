# =========================================
# 08-bootstrap-localhost.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Bootstrap Localhost ==="

$appsRoot = "C:\Apps"
$targetPath = "C:\Apps\ChristChurchGeelong"
$repoUrl = "https://github.com/KL0010/Anglican_Church_Australia.git"
$branch = "recovery-checkpoint"

if (!(Test-Path $appsRoot)) {
    Write-Host "Creating C:\Apps..."
    New-Item -ItemType Directory -Force -Path $appsRoot | Out-Null
}

if (Test-Path $targetPath) {
    Write-Host "[ERROR] Target folder already exists:"
    Write-Host $targetPath
    Write-Host ""
    Write-Host "Run these first:"
    Write-Host ".\06-backup-local-state.ps1"
    Write-Host ".\07-reset-local-app.ps1"
    exit 1
}

Write-Host "Cloning repository..."
git clone --branch $branch $repoUrl $targetPath

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Git clone failed"
    exit 1
}

Set-Location $targetPath

Write-Host ""
Write-Host "Restoring .NET packages..."
dotnet restore

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] dotnet restore failed"
    exit 1
}

Write-Host ""
Write-Host "Building application..."
dotnet build

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] dotnet build failed"
    exit 1
}

$appSettingsPath = Join-Path $targetPath "appsettings.Development.json"

if (!(Test-Path $appSettingsPath)) {
@'
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\MSSQLLocalDB;Database=AnglicanChurchAustralia_Local;Trusted_Connection=True;MultipleActiveResultSets=true"
  },
  "App": {
    "BastionHost": "app.localhost"
  },
  "Rag": {
    "BaseUrl": "https://app.localhost/",
    "ApiKey": ""
  },
  "RabbitMq": {
    "HostName": "localhost",
    "Port": 5672,
    "UserName": "",
    "Password": "",
    "VirtualHost": "/"
  },
  "AllowedHosts": "*"
}
'@ | Out-File $appSettingsPath -Encoding utf8

    Write-Host "[OK] Created appsettings.Development.json"
} else {
    Write-Host "[OK] appsettings.Development.json already exists"
}

Write-Host ""
Write-Host "========================================="
Write-Host "Bootstrap complete."
Write-Host "========================================="
Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Review appsettings.Development.json"
Write-Host "2. Add institution-owned API keys"
Write-Host "3. Run:"
Write-Host "   dotnet ef database update"
Write-Host "4. Run:"
Write-Host "   dotnet run"
Write-Host ""
Write-Host "Application path:"
Write-Host $targetPath