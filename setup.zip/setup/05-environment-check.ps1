# =========================================
# 05-environment-check.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Anglican Church Australia Localhost Environment Check ==="

function Write-Section {
    param([string]$Title)

    Write-Host ""
    Write-Host "========================================="
    Write-Host $Title
    Write-Host "========================================="
}

function Test-CommandExists {
    param([string]$Command)

    return [bool](Get-Command $Command -ErrorAction SilentlyContinue)
}

# -----------------------------------------
# .NET
# -----------------------------------------

Write-Section ".NET SDK / Runtime"

if (Test-CommandExists "dotnet") {
    Write-Host "[OK] dotnet found"
    dotnet --version
} else {
    Write-Host "[FAIL] dotnet not found"
}

# -----------------------------------------
# Git
# -----------------------------------------

Write-Section "Git"

if (Test-CommandExists "git") {
    Write-Host "[OK] git found"
    git --version
} else {
    Write-Host "[FAIL] git not found"
}

# -----------------------------------------
# Python / pip
# -----------------------------------------

Write-Section "Python / pip"

try {
    $pythonVersion = py --version 2>$null

    if ($LASTEXITCODE -eq 0) {
        Write-Host "[OK] Python found"
        Write-Host $pythonVersion

        $pipVersion = py -m pip --version 2>$null

        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] pip found"
            Write-Host $pipVersion
        } else {
            Write-Host "[FAIL] pip not working"
        }
    } else {
        Write-Host "[FAIL] Python not found"
    }
}
catch {
    Write-Host "[FAIL] Python check failed"
}

# -----------------------------------------
# Cloudflare Tunnel
# -----------------------------------------

Write-Section "Cloudflare Tunnel"

if (Test-CommandExists "cloudflared") {
    Write-Host "[OK] cloudflared found"
    cloudflared --version
} else {
    Write-Host "[FAIL] cloudflared not found"
}

# -----------------------------------------
# SQL LocalDB
# -----------------------------------------

Write-Section "SQL Server / LocalDB"

if (Test-CommandExists "sqllocaldb") {
    Write-Host "[OK] SQL LocalDB found"

    $instances = sqllocaldb info 2>$null

    if ($instances) {
        Write-Host "LocalDB instances:"
        $instances | ForEach-Object {
            Write-Host " - $_"
        }
    } else {
        Write-Host "[WARN] No LocalDB instances found"
    }
} else {
    Write-Host "[FAIL] SQL LocalDB not found"
}

# -----------------------------------------
# SQLCMD / Connection
# -----------------------------------------

Write-Section "SQL Connection Test"

if (Test-CommandExists "sqlcmd") {
    Write-Host "[OK] sqlcmd found"
    Write-Host "Testing connection to (localdb)\MSSQLLocalDB..."

    sqlcmd -S "(localdb)\MSSQLLocalDB" `
           -Q "SELECT @@VERSION" `
           -W 2>$null

    if ($LASTEXITCODE -eq 0) {
        Write-Host "[OK] LocalDB SQL connection successful"
    } else {
        Write-Host "[FAIL] LocalDB SQL connection failed"
    }
} else {
    Write-Host "[FAIL] sqlcmd not found"
}

# -----------------------------------------
# PowerShell Execution Policy
# -----------------------------------------

Write-Section "PowerShell Execution Policy"

$executionPolicy = Get-ExecutionPolicy -Scope CurrentUser
Write-Host "CurrentUser Policy: $executionPolicy"

if ($executionPolicy -eq "Restricted") {
    Write-Host "[WARN] PowerShell scripts may be blocked"
    Write-Host "Fix with:"
    Write-Host "Set-ExecutionPolicy -Scope CurrentUser RemoteSigned"
} else {
    Write-Host "[OK] Script execution allowed"
}

# -----------------------------------------
# Administrator Rights
# -----------------------------------------

Write-Section "Administrator Rights"

$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)

$isAdmin = $principal.IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)

if ($isAdmin) {
    Write-Host "[OK] Running as Administrator"
} else {
    Write-Host "[WARN] Not running as Administrator"
}

# -----------------------------------------
# C:\Apps
# -----------------------------------------

Write-Section "Applications Directory"

if (Test-Path "C:\Apps") {
    Write-Host "[OK] C:\Apps exists"
} else {
    Write-Host "[WARN] C:\Apps missing"
    Write-Host "Create it with:"
    Write-Host "New-Item -ItemType Directory -Force -Path C:\Apps"
}

# -----------------------------------------
# Final
# -----------------------------------------

Write-Host ""
Write-Host "========================================="
Write-Host "Environment check complete."
Write-Host "========================================="