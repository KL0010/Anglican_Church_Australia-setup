# =========================================
# 01-install-git.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Checking Git ==="

$gitExists = Get-Command git -ErrorAction SilentlyContinue

if ($gitExists) {

    Write-Host "[OK] Git already installed"
    git --version

} else {

    Write-Host "[MISSING] Git not found"
    Write-Host "Installing Git..."

    winget install Git.Git `
        --accept-source-agreements `
        --accept-package-agreements

    Write-Host ""
    Write-Host "Verifying installation..."

    $gitExists = Get-Command git -ErrorAction SilentlyContinue

    if ($gitExists) {
        Write-Host "[OK] Git installed successfully"
        git --version
    }
    else {
        Write-Host "[ERROR] Git installation failed"
        exit 1
    }
}

Write-Host ""
Write-Host "=== Git check complete ==="