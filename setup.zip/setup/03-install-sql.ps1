# =========================================
# 03-install-sql.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Checking SQL Server / LocalDB ==="

function Test-SqlLocalDb {

    $localDb = Get-Command "sqllocaldb" -ErrorAction SilentlyContinue

    if (-not $localDb) {
        return $false
    }

    try {

        $instances = sqllocaldb info 2>$null

        if ($LASTEXITCODE -eq 0) {

            Write-Host "[OK] SQL LocalDB found"

            if ($instances) {

                Write-Host "Existing LocalDB instances:"

                $instances | ForEach-Object {
                    Write-Host " - $_"
                }
            }

            return $true
        }

    }
    catch {}

    return $false
}

function Test-SqlCmd {

    $sqlcmd = Get-Command "sqlcmd" -ErrorAction SilentlyContinue

    if ($sqlcmd) {

        Write-Host "[OK] sqlcmd found"

        try {

            sqlcmd -S "(localdb)\MSSQLLocalDB" `
                   -Q "SELECT @@VERSION" `
                   -W 2>$null

            if ($LASTEXITCODE -eq 0) {

                Write-Host "[OK] LocalDB SQL connection successful"
                return $true
            }

        }
        catch {}
    }

    Write-Host "[WARN] sqlcmd missing or SQL connection failed"
    return $false
}

$sqlInstalled = Test-SqlLocalDb

if ($sqlInstalled) {

    Test-SqlCmd

    Write-Host ""
    Write-Host "=== SQL check complete ==="

    exit 0
}

Write-Host "[MISSING] SQL LocalDB not found"
Write-Host "Installing SQL Server Express..."

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {

    Write-Host "[ERROR] winget not found"
    exit 1
}

winget install Microsoft.SQLServer.2022.Express `
    --accept-source-agreements `
    --accept-package-agreements

Write-Host ""
Write-Host "Installing SQL Command Line Tools..."

winget install Microsoft.SQLServerCommandLineUtilities `
    --accept-source-agreements `
    --accept-package-agreements

Write-Host ""
Write-Host "Refreshing environment..."
Start-Sleep -Seconds 10

Write-Host ""
Write-Host "Verifying SQL installation..."

$sqlInstalled = Test-SqlLocalDb

if ($sqlInstalled) {

    Test-SqlCmd

    Write-Host ""
    Write-Host "[OK] SQL installation complete"
    Write-Host "=== SQL check complete ==="

    exit 0
}

Write-Host ""
Write-Host "[WARN] SQL installer completed but verification failed."
Write-Host "Close PowerShell, reopen as Administrator, then rerun:"
Write-Host ".\03-install-sql.ps1"

exit 0