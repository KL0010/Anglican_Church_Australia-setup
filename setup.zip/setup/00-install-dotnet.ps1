# =========================================
# 00-install-dotnet.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Checking .NET SDK ==="

$dotnetExists = Get-Command dotnet -ErrorAction SilentlyContinue

if ($dotnetExists) {

    Write-Host "[OK] dotnet already installed"
    dotnet --version

} else {

    Write-Host "[MISSING] dotnet not found"
    Write-Host "Installing .NET 8 SDK..."

    winget install Microsoft.DotNet.SDK.8 `
        --accept-source-agreements `
        --accept-package-agreements

    Write-Host ""
    Write-Host "Verifying installation..."

    $dotnetExists = Get-Command dotnet -ErrorAction SilentlyContinue

    if ($dotnetExists) {
        Write-Host "[OK] .NET SDK installed successfully"
        dotnet --version
    }
    else {
        Write-Host "[ERROR] .NET SDK installation failed"
        exit 1
    }
}

Write-Host ""
Write-Host "=== .NET check complete ==="