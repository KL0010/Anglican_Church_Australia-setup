# =========================================
# 02-install-python.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Checking Python ==="

function Refresh-Path {
    $machinePath = [System.Environment]::GetEnvironmentVariable(
        "Path",
        [System.EnvironmentVariableTarget]::Machine
    )

    $userPath = [System.Environment]::GetEnvironmentVariable(
        "Path",
        [System.EnvironmentVariableTarget]::User
    )

    $env:Path = "$machinePath;$userPath"
}

function Test-Python {
    Refresh-Path

    try {
        $pythonVersion = py --version 2>$null

        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] Python found via launcher:"
            Write-Host $pythonVersion

            $pipVersion = py -m pip --version 2>$null

            if ($LASTEXITCODE -eq 0) {
                Write-Host "[OK] pip found:"
                Write-Host $pipVersion
                return $true
            }

            Write-Host "[WARN] Python found, but pip is not working"
            return $false
        }
    }
    catch {}

    return $false
}

$pythonOk = Test-Python

if ($pythonOk) {
    Write-Host ""
    Write-Host "=== Python check complete ==="
    exit 0
}

Write-Host "[MISSING] Real Python installation not found"
Write-Host "Installing Python 3.12..."

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host "[ERROR] winget not found. Install App Installer from Microsoft Store."
    exit 1
}

winget install Python.Python.3.12 `
    --accept-source-agreements `
    --accept-package-agreements

Write-Host ""
Write-Host "Refreshing PATH..."
Start-Sleep -Seconds 5
Refresh-Path

Write-Host ""
Write-Host "Verifying Python installation..."

$pythonOk = Test-Python

if ($pythonOk) {
    Write-Host ""
    Write-Host "[OK] Python installed successfully"
    Write-Host "=== Python check complete ==="
    exit 0
}

Write-Host ""
Write-Host "[WARN] Python installer completed, but this PowerShell session cannot see Python yet."
Write-Host "Close this PowerShell window, reopen as Administrator, then run:"
Write-Host "py --version"
Write-Host "py -m pip --version"
Write-Host ".\05-environment-check.ps1"

exit 0