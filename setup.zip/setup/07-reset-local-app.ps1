# =========================================
# 07-reset-local-app.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Reset Local App ==="

# -----------------------------------------
# Ask for parish / institution name
# -----------------------------------------

$parishName = Read-Host "Enter parish/institution folder name"

if ([string]::IsNullOrWhiteSpace($parishName)) {
    Write-Host "[ERROR] Parish/institution name cannot be empty"
    exit 1
}

# -----------------------------------------
# Paths
# -----------------------------------------

$appsRoot = "C:\Apps"
$parishRoot = Join-Path $appsRoot $parishName
$projectPath = Join-Path $parishRoot "Anglican_Church_Australia"

# -----------------------------------------
# Ensure project exists
# -----------------------------------------

if (!(Test-Path $projectPath)) {
    Write-Host "[WARN] Project folder does not exist:"
    Write-Host $projectPath
    exit 0
}

# -----------------------------------------
# Safety warning
# -----------------------------------------

Write-Host ""
Write-Host "WARNING:"
Write-Host "This will permanently delete the local application folder:"
Write-Host $projectPath
Write-Host ""
Write-Host "This will NOT delete:"
Write-Host "- backups"
Write-Host "- FastAPI"
Write-Host "- publish"
Write-Host "- scripts"
Write-Host "- state"
Write-Host "- logs"
Write-Host ""

$confirmation = Read-Host "Type DELETE to continue"

if ($confirmation -ne "DELETE") {
    Write-Host ""
    Write-Host "[CANCELLED] Reset aborted"
    exit 0
}

# -----------------------------------------
# Remove project
# -----------------------------------------

Write-Host ""
Write-Host "Removing local application folder..."

try {
    Remove-Item `
        $projectPath `
        -Recurse `
        -Force

    Write-Host "[OK] Local application removed"
}
catch {
    Write-Host "[ERROR] Failed to remove local application"
    Write-Host $_.Exception.Message
    exit 1
}

# -----------------------------------------
# Final
# -----------------------------------------

Write-Host ""
Write-Host "========================================="
Write-Host "Local app reset complete"
Write-Host "========================================="
Write-Host "Removed:"
Write-Host $projectPath