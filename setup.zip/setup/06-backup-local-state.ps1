# =========================================
# 06-backup-local-state.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Backup Local State ==="

# -----------------------------------------
# Ask for parish / institution name
# -----------------------------------------

$parishName = Read-Host "Enter parish/institution folder name"

if ([string]::IsNullOrWhiteSpace($parishName)) {
    Write-Host "[ERROR] Parish/institution name cannot be empty"
    exit 1
}

# -----------------------------------------
# Paths
# -----------------------------------------

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

$appsRoot = "C:\Apps"
$parishRoot = Join-Path $appsRoot $parishName
$projectPath = Join-Path $parishRoot "Anglican_Church_Australia"
$backupRoot = Join-Path $parishRoot "backups"
$backupDir = Join-Path $backupRoot "ACA-Local-Backup-$timestamp"

# -----------------------------------------
# Ensure parish root exists
# -----------------------------------------

if (!(Test-Path $parishRoot)) {
    Write-Host "[WARN] Parish root does not exist:"
    Write-Host $parishRoot
    exit 0
}

# -----------------------------------------
# Ensure project exists
# -----------------------------------------

if (!(Test-Path $projectPath)) {
    Write-Host "[WARN] Project path does not exist:"
    Write-Host $projectPath
    exit 0
}

# -----------------------------------------
# Ensure backup root exists
# -----------------------------------------

if (!(Test-Path $backupRoot)) {
    New-Item `
        -ItemType Directory `
        -Path $backupRoot `
        -Force | Out-Null
}

# -----------------------------------------
# Create backup directory
# -----------------------------------------

New-Item `
    -ItemType Directory `
    -Path $backupDir `
    -Force | Out-Null

# -----------------------------------------
# Backup important config files
# -----------------------------------------

$filesToBackup = @(
    "appsettings.json",
    "appsettings.Development.json"
)

foreach ($file in $filesToBackup) {
    $source = Join-Path $projectPath $file

    if (Test-Path $source) {
        Copy-Item `
            $source `
            $backupDir `
            -Force

        Write-Host "[OK] Backed up $file"
    }
    else {
        Write-Host "[WARN] Missing $file"
    }
}

# -----------------------------------------
# Backup Cloudflare config if present
# -----------------------------------------

$cloudflareConfig = "$env:USERPROFILE\.cloudflared"

if (Test-Path $cloudflareConfig) {
    $cloudflareBackup = Join-Path $backupDir "cloudflared"

    Copy-Item `
        $cloudflareConfig `
        $cloudflareBackup `
        -Recurse `
        -Force

    Write-Host "[OK] Backed up Cloudflare tunnel config"
}
else {
    Write-Host "[WARN] No Cloudflare config found at:"
    Write-Host $cloudflareConfig
}

# -----------------------------------------
# Final
# -----------------------------------------

Write-Host ""
Write-Host "========================================="
Write-Host "Backup complete"
Write-Host "========================================="
Write-Host "Parish root:"
Write-Host $parishRoot
Write-Host ""
Write-Host "Backup location:"
Write-Host $backupDir