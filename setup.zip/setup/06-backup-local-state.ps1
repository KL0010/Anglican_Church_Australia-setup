# =========================================
# 06-backup-local-state.ps1
# Anglican Church Australia
# =========================================

Write-Host "=== Backup Local State ==="

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

$projectPath = "C:\Apps\ChristChurchGeelong"

$backupRoot = "C:\Apps\Backups"

$backupDir = Join-Path $backupRoot "ACA-Local-Backup-$timestamp"

# -----------------------------------------
# Ensure backup root exists
# -----------------------------------------

if (!(Test-Path $backupRoot)) {

    New-Item `
        -ItemType Directory `
        -Path $backupRoot `
        -Force | Out-Null
}

# -----------------------------------------
# Ensure project exists
# -----------------------------------------

if (!(Test-Path $projectPath)) {

    Write-Host "[WARN] Project path does not exist:"
    Write-Host $projectPath
    exit 0
}

# -----------------------------------------
# Create backup directory
# -----------------------------------------

New-Item `
    -ItemType Directory `
    -Path $backupDir `
    -Force | Out-Null

# -----------------------------------------
# Backup important files
# -----------------------------------------

$filesToBackup = @(
    "appsettings.json",
    "appsettings.Development.json"
)

foreach ($file in $filesToBackup) {

    $source = Join-Path $projectPath $file

    if (Test-Path $source) {

        Copy-Item `
            $source `
            $backupDir `
            -Force

        Write-Host "[OK] Backed up $file"

    } else {

        Write-Host "[WARN] Missing $file"
    }
}

# -----------------------------------------
# Backup Cloudflare config if present
# -----------------------------------------

$cloudflareConfig = "$env:USERPROFILE\.cloudflared"

if (Test-Path $cloudflareConfig) {

    $cloudflareBackup = Join-Path $backupDir "cloudflared"

    Copy-Item `
        $cloudflareConfig `
        $cloudflareBackup `
        -Recurse `
        -Force

    Write-Host "[OK] Backed up Cloudflare tunnel config"
}

# -----------------------------------------
# Final
# -----------------------------------------

Write-Host ""
Write-Host "========================================="
Write-Host "Backup complete"
Write-Host "========================================="
Write-Host $backupDir